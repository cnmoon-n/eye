muban.首图2.二级.tabs = '.stui-pannel__head&&h3';
var rule = Object.assign(muban.首图2,{
title:'完美看看',
host:'https://www.wanmeikk.film',
url:'/category/fyclass-fypage.html',
searchUrl:'/vodsearch/**-------------.html',
class_name:'电影&美剧&韩剧&日剧&国产剧&动漫',//静态分类名称拼接
class_url:'1&2&3&4&5&6',//静态分类标识拼接
class_parse:'',
});
