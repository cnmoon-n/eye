var rule = Object.assign(muban.mxpro,{
title:'555影视',
// host:'https://www.555dy.app',
host:'https://www.555yy2.com/',
headers:{//网站的请求头,完整支持所有的,常带ua和cookies
    'User-Agent':'MOBILE_UA',
    "Cookie": "searchneed=ok"
},
});